-- CreateTable
CREATE TABLE `teachers` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `fullname` VARCHAR(191) NOT NULL,
    `email` VARCHAR(191) NOT NULL,
    `identity_number` VARCHAR(191) NOT NULL,
    `password` VARCHAR(191) NOT NULL,
    `class_id` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `update_at` DATETIME(3) NOT NULL,
    `role` ENUM('TEACHER', 'ADMIN') NOT NULL,
    `position` ENUM('TEACHER', 'HEADMASTER', 'COMMITTEE') NOT NULL,

    UNIQUE INDEX `teachers_email_key`(`email`),
    UNIQUE INDEX `teachers_identity_number_key`(`identity_number`),
    INDEX `idx_teacher_classId`(`class_id`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `class` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(191) NOT NULL,
    `category` ENUM('A', 'B') NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `update_at` DATETIME(3) NOT NULL,

    UNIQUE INDEX `class_name_key`(`name`),
    INDEX `idx_class_name`(`name`),
    INDEX `idx_class_category`(`category`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `periods` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `semester` ENUM('GANJIL', 'GENAP') NOT NULL,
    `year` VARCHAR(191) NOT NULL DEFAULT '2025',
    `isActive` BOOLEAN NOT NULL DEFAULT false,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `update_at` DATETIME(3) NOT NULL,

    INDEX `idx_period_isActive`(`isActive`),
    INDEX `idx_period_semester_year`(`semester`, `year`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `themes` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `title` VARCHAR(191) NOT NULL,
    `periodId` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `update_at` DATETIME(3) NOT NULL,

    INDEX `idx_theme_title`(`title`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `indicators` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `title` VARCHAR(191) NOT NULL,
    `description` VARCHAR(191) NOT NULL,
    `assesment_type` ENUM('NILAI_AGAMA_DAN_BUDI_PEKERTI', 'JATI_DIRI', 'DASAR_LITERASI_MATEMATIKA_SAINS_TEKNOLOGI_REKAYASA_DAN_SENI') NOT NULL,
    `themeId` INTEGER NOT NULL,
    `periodId` INTEGER NULL,
    `classCategory` ENUM('A', 'B') NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `update_at` DATETIME(3) NOT NULL,

    INDEX `idx_indicator_themeId`(`themeId`),
    INDEX `idx_indicator_assessmentType`(`assesment_type`),
    INDEX `idx_indicator_classCategory`(`classCategory`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `students` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `fullname` VARCHAR(191) NOT NULL,
    `gender` ENUM('LAKI_LAKI', 'PEREMPUAN') NOT NULL,
    `religion` ENUM('ISLAM', 'KRISTEN', 'KATOLIK', 'KONGHUCU', 'BUDDHA', 'HINDU') NOT NULL,
    `parent_name` VARCHAR(191) NULL,
    `birth_place` VARCHAR(191) NOT NULL,
    `birth_date` DATETIME(3) NOT NULL,
    `class_id` INTEGER NULL,
    `address` VARCHAR(191) NULL,
    `currentPeriod` INTEGER NULL,
    `classAndPeriod` JSON NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `update_at` DATETIME(3) NOT NULL,

    INDEX `idx_student_fullname`(`fullname`),
    INDEX `idx_student_classId`(`class_id`),
    INDEX `idx_student_gender`(`gender`),
    INDEX `idx_student_religion`(`religion`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `student_scores` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `studentId` INTEGER NOT NULL,
    `periodId` INTEGER NULL,
    `teacherId` INTEGER NULL,
    `indicatorId` INTEGER NULL,
    `description` VARCHAR(191) NULL,
    `value` ENUM('BB', 'MB', 'BSH', 'BSB') NOT NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `update_at` DATETIME(3) NOT NULL,

    INDEX `idx_studentId`(`studentId`),
    INDEX `idx_indicatorId`(`indicatorId`),
    INDEX `idx_periodId`(`periodId`),
    INDEX `idx_score_teacherId`(`teacherId`),
    INDEX `idx_score_value`(`value`),
    INDEX `idx_composite`(`studentId`, `indicatorId`, `periodId`),
    UNIQUE INDEX `student_scores_studentId_teacherId_periodId_indicatorId_key`(`studentId`, `teacherId`, `periodId`, `indicatorId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `reflections` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `studentId` INTEGER NOT NULL,
    `periodId` INTEGER NULL,
    `teacherId` INTEGER NULL,
    `classId` INTEGER NULL,
    `description` VARCHAR(191) NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `update_at` DATETIME(3) NOT NULL,

    INDEX `idx_reflection_studentId`(`studentId`),
    INDEX `idx_reflection_periodId`(`periodId`),
    INDEX `idx_reflection_teacherId`(`teacherId`),
    INDEX `idx_reflection_classId`(`classId`),
    INDEX `idx_reflection_composite`(`studentId`, `periodId`),
    UNIQUE INDEX `reflections_studentId_teacherId_periodId_classId_key`(`studentId`, `teacherId`, `periodId`, `classId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `attendances` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `studentId` INTEGER NOT NULL,
    `periodId` INTEGER NULL,
    `teacherId` INTEGER NULL,
    `classId` INTEGER NULL,
    `sick` INTEGER NULL,
    `permit` INTEGER NULL,
    `absent` INTEGER NULL,
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `update_at` DATETIME(3) NOT NULL,

    INDEX `idx_attendance_studentId`(`studentId`),
    INDEX `idx_attendance_periodId`(`periodId`),
    INDEX `idx_attendance_teacherId`(`teacherId`),
    INDEX `idx_attendance_classId`(`classId`),
    INDEX `idx_attendance_composite`(`studentId`, `periodId`),
    UNIQUE INDEX `attendances_studentId_teacherId_periodId_classId_key`(`studentId`, `teacherId`, `periodId`, `classId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `student_developments` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `height` DOUBLE NULL,
    `weight` DOUBLE NULL,
    `notes` VARCHAR(191) NULL,
    `studentId` INTEGER NOT NULL,
    `teacherId` INTEGER NOT NULL,
    `periodId` INTEGER NOT NULL,
    `record_date` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updated_at` DATETIME(3) NOT NULL,

    INDEX `idx_development_studentId`(`studentId`),
    INDEX `idx_development_teacherId`(`teacherId`),
    INDEX `idx_development_periodId`(`periodId`),
    INDEX `idx_development_recordDate`(`record_date`),
    INDEX `idx_development_student_period`(`studentId`, `periodId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `teachers` ADD CONSTRAINT `teachers_class_id_fkey` FOREIGN KEY (`class_id`) REFERENCES `class`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `themes` ADD CONSTRAINT `themes_periodId_fkey` FOREIGN KEY (`periodId`) REFERENCES `periods`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `indicators` ADD CONSTRAINT `indicators_themeId_fkey` FOREIGN KEY (`themeId`) REFERENCES `themes`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `indicators` ADD CONSTRAINT `indicators_periodId_fkey` FOREIGN KEY (`periodId`) REFERENCES `periods`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `students` ADD CONSTRAINT `students_currentPeriod_fkey` FOREIGN KEY (`currentPeriod`) REFERENCES `periods`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `students` ADD CONSTRAINT `students_class_id_fkey` FOREIGN KEY (`class_id`) REFERENCES `class`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `student_scores` ADD CONSTRAINT `student_scores_studentId_fkey` FOREIGN KEY (`studentId`) REFERENCES `students`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `student_scores` ADD CONSTRAINT `student_scores_periodId_fkey` FOREIGN KEY (`periodId`) REFERENCES `periods`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `student_scores` ADD CONSTRAINT `student_scores_indicatorId_fkey` FOREIGN KEY (`indicatorId`) REFERENCES `indicators`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `student_scores` ADD CONSTRAINT `student_scores_teacherId_fkey` FOREIGN KEY (`teacherId`) REFERENCES `teachers`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `reflections` ADD CONSTRAINT `reflections_studentId_fkey` FOREIGN KEY (`studentId`) REFERENCES `students`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `reflections` ADD CONSTRAINT `reflections_periodId_fkey` FOREIGN KEY (`periodId`) REFERENCES `periods`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `reflections` ADD CONSTRAINT `reflections_teacherId_fkey` FOREIGN KEY (`teacherId`) REFERENCES `teachers`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `reflections` ADD CONSTRAINT `reflections_classId_fkey` FOREIGN KEY (`classId`) REFERENCES `class`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `attendances` ADD CONSTRAINT `attendances_studentId_fkey` FOREIGN KEY (`studentId`) REFERENCES `students`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `attendances` ADD CONSTRAINT `attendances_periodId_fkey` FOREIGN KEY (`periodId`) REFERENCES `periods`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `attendances` ADD CONSTRAINT `attendances_teacherId_fkey` FOREIGN KEY (`teacherId`) REFERENCES `teachers`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `attendances` ADD CONSTRAINT `attendances_classId_fkey` FOREIGN KEY (`classId`) REFERENCES `class`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `student_developments` ADD CONSTRAINT `student_developments_teacherId_fkey` FOREIGN KEY (`teacherId`) REFERENCES `teachers`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `student_developments` ADD CONSTRAINT `student_developments_studentId_fkey` FOREIGN KEY (`studentId`) REFERENCES `students`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `student_developments` ADD CONSTRAINT `student_developments_periodId_fkey` FOREIGN KEY (`periodId`) REFERENCES `periods`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
