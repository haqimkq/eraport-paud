import { ClassController } from '@/services/api/class';

export const { GET_ID: GET, UPDATE: PUT, DELETE } = ClassController;
