import { ClassController } from '@/services/api/class';

export const { GET, POST } = ClassController;
