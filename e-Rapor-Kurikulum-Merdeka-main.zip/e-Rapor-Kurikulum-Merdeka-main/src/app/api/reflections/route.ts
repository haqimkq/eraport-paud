import { ReflectionController } from '@/services/api/reflection';

export const { GET_BY_CLASS_AND_ACTIVE_PERIOD: GET, UPSERT: POST } =
    ReflectionController;
