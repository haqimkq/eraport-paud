import { AssessmentController } from '@/services/api/assessment';

export const { UPSERT: POST } = AssessmentController;
