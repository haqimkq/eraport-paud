import { AssessmentController } from '@/services/api/assessment';

export const { GET_BY_STUDENT: GET } = AssessmentController;
