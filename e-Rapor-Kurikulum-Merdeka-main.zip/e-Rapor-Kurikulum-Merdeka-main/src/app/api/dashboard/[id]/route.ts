import { DashboardController } from '@/services/api/dashboard';

export const { GET } = DashboardController;
