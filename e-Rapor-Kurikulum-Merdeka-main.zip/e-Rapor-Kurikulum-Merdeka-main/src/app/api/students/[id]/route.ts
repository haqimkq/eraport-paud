import { StudentController } from '@/services/api/(user)/students/controller';

export const { GET_ID: GET, UPDATE: PUT, DELETE } = StudentController;
