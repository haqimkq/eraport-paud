import { StudentController } from '@/services/api/(user)/students/controller';

export const { GET, POST } = StudentController;
