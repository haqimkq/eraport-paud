import { TeacherController } from '@/services/api/(user)/teachers';

export const { GET, POST } = TeacherController;
