import { TeacherController } from '@/services/api/(user)/teachers';

export const { GET_ID: GET, UPDATE: PUT, DELETE } = TeacherController;
