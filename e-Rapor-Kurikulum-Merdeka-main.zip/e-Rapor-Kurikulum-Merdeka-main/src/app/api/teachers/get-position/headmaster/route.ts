import { TeacherController } from '@/services/api/(user)/teachers';

export const { GET_HEADMASTER: GET } = TeacherController;
