import { PeriodController } from '@/services/api/period';

export const { GET, POST } = PeriodController;
