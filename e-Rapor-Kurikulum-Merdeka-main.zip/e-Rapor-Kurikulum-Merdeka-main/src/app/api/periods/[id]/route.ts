import { PeriodController } from '@/services/api/period';

export const { UPDATE: PUT, DELETE } = PeriodController;
