import { PeriodController } from '@/services/api/period';

export const { GET_ACTIVE_PERIOD: GET } = PeriodController;
