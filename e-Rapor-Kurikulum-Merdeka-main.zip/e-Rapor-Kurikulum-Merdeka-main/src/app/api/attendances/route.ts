import { StudentAttendanceController } from '@/services/api/attendance';

export const { GET, UPSERT: POST } = StudentAttendanceController;
