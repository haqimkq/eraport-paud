import { IndicatorController } from '@/services/api/indicator';

export const { GET_BY_CLASS_CATEGORY: GET } = IndicatorController;
