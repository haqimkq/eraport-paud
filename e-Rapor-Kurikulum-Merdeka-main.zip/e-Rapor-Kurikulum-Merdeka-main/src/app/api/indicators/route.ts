import { IndicatorController } from '@/services/api/indicator';

export const { GET, POST } = IndicatorController;
