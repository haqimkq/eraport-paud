import { IndicatorController } from '@/services/api/indicator';

export const { GET_ID: GET, UPDATE: PUT, DELETE } = IndicatorController;
