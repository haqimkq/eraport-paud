import { ThemeController } from '@/services/api/theme';

export const { GET_ID: GET, UPDATE: PUT, DELETE } = ThemeController;
