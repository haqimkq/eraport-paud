import { ThemeController } from '@/services/api/theme';

export const { GET, POST } = ThemeController;
