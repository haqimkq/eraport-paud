import { StudentDevelopmentController } from '@/services/api/development';

export const { GET, UPSERT: POST } = StudentDevelopmentController;
