import { StudentDevelopmentController } from '@/services/api/development';

export const { GET_ID: GET } = StudentDevelopmentController;
