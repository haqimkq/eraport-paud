export { default } from './(pages)/(auth)/login/page';
